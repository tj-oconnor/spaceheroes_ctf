#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <unistd.h>

__attribute__((constructor)) void ignore_me() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}


int main() {
	printf("\"This is our chance to destroy the Death Star, Luke\"\n");
	printf("You feel a system at %p\n", system);
	char * hint;
	hint = (char *) malloc(136);
	printf("You feel something else at %p\n", (hint - 16));
	free(hint);
	for(int i = 0; i < 4; i++) {
		puts("(1) Reach out with the force");
		puts("(2) Surrender");
		unsigned int choice;
		scanf("%u", &choice);
		if(choice == 2) {
			break;
		}
		else {
			printf("How many midi-chlorians?: ");
			unsigned long long size;
			scanf("%llu", &size);
			printf("What do you feel?: ");
			char* data = (char *) malloc(size);
			read(0, data, malloc_usable_size(data)+8);
		}
	}

}
