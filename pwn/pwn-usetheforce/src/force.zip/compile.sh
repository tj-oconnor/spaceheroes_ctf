#!/bin/bash
gcc -Wl,--rpath=./.glibc/glibc_2.28_no-tcache -Wl,--dynamic-linker=./.glibc/glibc_2.28_no-tcache/ld.so.2 -o force force.c -no-pie
